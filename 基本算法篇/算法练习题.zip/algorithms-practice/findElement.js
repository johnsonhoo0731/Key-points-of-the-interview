// 问题：在数组中找到第 k 大的元素。
// 例如：
// findElement([4,6,1,9,7],1)//9
// findElement([2,8,3,4],2)//4

function findElement() {}
