// 问题：请编写一个linearSearch的函数，函数接收一个数组arr和搜索值n,若n值存在于数组当中，则返回对应的index下标，若不存在于数组中，则返回-1（使用线性搜索）。
// 例如：
// linearSearch([10,15,20,25,30],15)//1
// linearSearch([1,2,3,4,5],6)//-1

function linearSearch() {}
