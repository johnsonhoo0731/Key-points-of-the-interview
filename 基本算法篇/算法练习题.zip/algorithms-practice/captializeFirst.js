// 问题：请使用递归，实现传入的数组中每一项字符串的首字母转换为大写。
// 例如：
// capitalizeFirst(['hello', 'henry', 'summer']) // ['Hello', 'Henry','Summer']

function capitalizeFirst() {}
