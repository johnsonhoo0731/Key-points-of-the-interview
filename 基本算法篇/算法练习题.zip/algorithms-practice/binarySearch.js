// 问题：请编写一个binarySearch的函数，函数接收一个已经排序好的数组sortedArr和查找值n,若n值存在于数组当中，则返回第一次出现的index下标，若不存在于数组中，则返回-1（使用二分查找）。
// 例如：
// binarySearch([5，6，10，13，14，18，30，34，35，37，50],10)//2
// binarySearch([1,2,3,4],4)//3
// binarySearch([1,2,3,4,5],6)//-1

function binarySearch() {}
