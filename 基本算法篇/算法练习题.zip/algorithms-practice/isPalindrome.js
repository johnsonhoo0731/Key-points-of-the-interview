// 问题：请使用递归，验证输入的字符串是否为回文字符串。
// 例如：
// isPalindrome(awesome) // false
// isPalindrome(welcome) // false
// isPalindrome(tacocat) // true
// isPalindrome(amanaplanacanalpanama) //true

function isPalindrome() {}
