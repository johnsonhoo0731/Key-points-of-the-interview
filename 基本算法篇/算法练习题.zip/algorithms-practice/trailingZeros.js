// 问题：请编写一个trailingZeros的函数，计算出n阶乘中尾部零的个数。（要求时间复杂度为O(logn)）
// 例如：
// trailingZeros(11)//2  11！= 39916800 ，结尾的0有2个。
// trailingZeros(5)//1 5！= 120，结尾的0有1个。

function trailingZeros() {}
